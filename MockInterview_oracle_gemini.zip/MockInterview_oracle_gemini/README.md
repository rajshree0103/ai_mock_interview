# MockInterview - AI Mock Interview System
## (Oracle XE + Google Gemini Edition)

A Spring Boot web application for AI-powered mock interviews.
- **Database**: Oracle XE (via JDBC)
- **AI**: Google Gemini 2.0 Flash API (free tier available)
- **Backend**: Spring Boot 3.2, Hibernate/JPA, Thymeleaf
- **Build**: Maven

---

## Prerequisites

| Tool | Version |
|------|---------|
| Java JDK | 17+ |
| Maven | 3.6+ |
| Oracle XE | 21c or 18c (free) |
| Oracle JDBC Driver | ojdbc11 |

---

## Step 1 — Install Oracle XE (Free)

Download Oracle Database XE from:
https://www.oracle.com/database/technologies/xe-downloads.html

Default connection: `localhost:1521` service `XE`

---

## Step 2 — Add Oracle JDBC Driver

Oracle JDBC is NOT on Maven Central. You must install it manually:

```bash
# Download ojdbc11.jar from:
# https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html

mvn install:install-file \
  -Dfile=ojdbc11.jar \
  -DgroupId=com.oracle.database.jdbc \
  -DartifactId=ojdbc11 \
  -Dversion=23.3.0.23.09 \
  -Dpackaging=jar
```

---

## Step 3 — Set Up Database

Open SQL*Plus and run `database_setup.sql`:

```
sqlplus sys/yourpassword@XE as sysdba
@database_setup.sql
```

This creates the `mockinterview` user and all tables.

---

## Step 4 — Get a Free Gemini API Key

1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with your Google account
3. Click **Create API Key**
4. Copy the key

---

## Step 5 — Configure the App

Edit `src/main/resources/application.properties`:

```properties
# Oracle connection (update password if different)
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:XE
spring.datasource.username=mockinterview
spring.datasource.password=mockinterview

# Paste your Gemini API key here
ai.api.key=YOUR_GEMINI_API_KEY_HERE
```

---

## Step 6 — Build and Run

```bash
mvn clean package -DskipTests
java -jar target/MockInterview-1.0.0.jar
```

Open browser: http://localhost:8080

---

## Running Without Gemini API Key

If you leave `ai.api.key` blank or as the placeholder, the app automatically
falls back to the built-in rule-based question bank and evaluator.
No API key is required to run the application.

---

## Application URLs

| URL | Description |
|-----|-------------|
| http://localhost:8080 | Home / Login |
| http://localhost:8080/register | Register |
| http://localhost:8080/dashboard | Dashboard |
| http://localhost:8080/api/health | Health check |

