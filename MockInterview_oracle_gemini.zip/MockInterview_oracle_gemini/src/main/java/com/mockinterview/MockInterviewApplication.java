package com.mockinterview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Main entry point for the MockInterview Spring Boot Application.
 * Extends SpringBootServletInitializer for WAR deployment (NetBeans / Tomcat).
 * @ServletComponentScan enables traditional Servlet scanning.
 */
@SpringBootApplication
@ServletComponentScan
public class MockInterviewApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(MockInterviewApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(MockInterviewApplication.class, args);
        System.out.println("==========================================");
        System.out.println("  MockInterview App Started Successfully!");
        System.out.println("  URL: http://localhost:8080");
        System.out.println("==========================================");
    }
}
