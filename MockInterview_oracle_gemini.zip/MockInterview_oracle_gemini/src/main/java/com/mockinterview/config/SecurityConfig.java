package com.mockinterview.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * SecurityConfig - configures Spring Security.
 * We use custom session-based auth (not Spring Security login),
 * so we disable default login and permit all routes.
 * BCrypt is used for password hashing.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * BCryptPasswordEncoder bean for password hashing.
     */
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Security filter chain - allows our custom servlet/controller-based auth.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF for simplicity (enable in production)
            .csrf(csrf -> csrf.disable())
            // Permit all requests - our controllers handle auth via HTTP session
            .authorizeHttpRequests(auth -> auth
                .anyRequest().permitAll()
            )
            // Disable default login page
            .formLogin(form -> form.disable())
            // Disable HTTP Basic
            .httpBasic(basic -> basic.disable());

        return http.build();
    }
}
