package com.mockinterview.repository;

import com.mockinterview.model.InterviewSession;
import com.mockinterview.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * InterviewSessionRepository - Spring Data JPA for sessions.
 */
@Repository
public interface InterviewSessionRepository extends JpaRepository<InterviewSession, Long> {

    // Get all sessions for a user, newest first
    List<InterviewSession> findByUserOrderByCreatedAtDesc(User user);

    // Get completed sessions for a user
    List<InterviewSession> findByUserAndStatusOrderByCreatedAtDesc(User user, String status);

    // Count sessions by user
    long countByUser(User user);

    // Find in-progress session for user
    @Query("SELECT s FROM InterviewSession s WHERE s.user = :user AND s.status = 'IN_PROGRESS' ORDER BY s.createdAt DESC")
    List<InterviewSession> findActiveSessionByUser(User user);
}
