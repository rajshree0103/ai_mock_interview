package com.mockinterview.repository;

import com.mockinterview.model.InterviewAnswer;
import com.mockinterview.model.InterviewSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * InterviewAnswerRepository - Spring Data JPA for answers.
 */
@Repository
public interface InterviewAnswerRepository extends JpaRepository<InterviewAnswer, Long> {

    // Get all answers for a session, ordered by question number
    List<InterviewAnswer> findBySessionOrderByQuestionNumber(InterviewSession session);

    // Count answers in a session
    long countBySession(InterviewSession session);

    // Get average score for a session
    @Query("SELECT AVG(a.score) FROM InterviewAnswer a WHERE a.session = :session")
    Double getAverageScoreBySession(InterviewSession session);
}
