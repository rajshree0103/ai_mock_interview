package com.mockinterview.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * InterviewAnswer Entity - stores each question, user answer, and AI evaluation.
 */
@Entity
@Table(name = "interview_answers")
public class InterviewAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "answers_gen")
    @SequenceGenerator(name = "answers_gen", sequenceName = "interview_answers_seq", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "session_id", nullable = false)
    private InterviewSession session;

    @Column(name = "question_number")
    private int questionNumber;

    @Column(name = "question", columnDefinition = "CLOB", nullable = false)
    private String question;

    @Column(name = "user_answer", columnDefinition = "CLOB")
    private String userAnswer;

    @Column(name = "score")
    private double score; // 0-10

    @Column(name = "ai_feedback", columnDefinition = "CLOB")
    private String aiFeedback;

    @Column(name = "improvement", columnDefinition = "CLOB")
    private String improvement;

    @Column(name = "answered_at")
    private LocalDateTime answeredAt;

    @PrePersist
    protected void onCreate() {
        answeredAt = LocalDateTime.now();
    }

    // Constructors
    public InterviewAnswer() {}

    public InterviewAnswer(InterviewSession session, int questionNumber, String question) {
        this.session = session;
        this.questionNumber = questionNumber;
        this.question = question;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public InterviewSession getSession() { return session; }
    public void setSession(InterviewSession session) { this.session = session; }

    public int getQuestionNumber() { return questionNumber; }
    public void setQuestionNumber(int questionNumber) { this.questionNumber = questionNumber; }

    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }

    public String getUserAnswer() { return userAnswer; }
    public void setUserAnswer(String userAnswer) { this.userAnswer = userAnswer; }

    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }

    public String getAiFeedback() { return aiFeedback; }
    public void setAiFeedback(String aiFeedback) { this.aiFeedback = aiFeedback; }

    public String getImprovement() { return improvement; }
    public void setImprovement(String improvement) { this.improvement = improvement; }

    public LocalDateTime getAnsweredAt() { return answeredAt; }
    public void setAnsweredAt(LocalDateTime answeredAt) { this.answeredAt = answeredAt; }
}
