package com.mockinterview.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

/**
 * InterviewSession Entity - stores each mock interview session per user.
 */
@Entity
@Table(name = "interview_sessions")
public class InterviewSession {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sessions_gen")
    @SequenceGenerator(name = "sessions_gen", sequenceName = "interview_sessions_seq", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "job_role", nullable = false)
    private String jobRole;

    @Column(name = "total_questions")
    private int totalQuestions;

    @Column(name = "total_score")
    private double totalScore;

    @Column(name = "average_score")
    private double averageScore;

    @Column(name = "status")
    private String status = "IN_PROGRESS"; // IN_PROGRESS, COMPLETED

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @OneToMany(mappedBy = "session", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<InterviewAnswer> answers;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Constructors
    public InterviewSession() {}

    public InterviewSession(User user, String jobRole) {
        this.user = user;
        this.jobRole = jobRole;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getJobRole() { return jobRole; }
    public void setJobRole(String jobRole) { this.jobRole = jobRole; }

    public int getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(int totalQuestions) { this.totalQuestions = totalQuestions; }

    public double getTotalScore() { return totalScore; }
    public void setTotalScore(double totalScore) { this.totalScore = totalScore; }

    public double getAverageScore() { return averageScore; }
    public void setAverageScore(double averageScore) { this.averageScore = averageScore; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public List<InterviewAnswer> getAnswers() { return answers; }
    public void setAnswers(List<InterviewAnswer> answers) { this.answers = answers; }
}
