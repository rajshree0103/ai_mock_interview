package com.mockinterview.controller;

import com.mockinterview.model.InterviewAnswer;
import com.mockinterview.model.InterviewSession;
import com.mockinterview.model.User;
import com.mockinterview.service.InterviewService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/**
 * InterviewRestController - RESTful API endpoints for the interview system.
 * These act as microservice endpoints called via AJAX from the frontend.
 * 
 * Endpoints:
 *   POST /api/interview/start        - Start a new interview session
 *   POST /api/interview/submit       - Submit answer for a question
 *   POST /api/interview/complete     - Complete the session
 *   GET  /api/interview/session/{id} - Get session details
 */
@RestController
@RequestMapping("/api/interview")
public class InterviewRestController {

    @Autowired
    private InterviewService interviewService;

    /**
     * Start a new interview session.
     * POST /api/interview/start
     * Body: { "jobRole": "Java Developer" }
     */
    @PostMapping("/start")
    public ResponseEntity<Map<String, Object>> startInterview(
            @RequestBody Map<String, String> body,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Please login first."));
        }

        String jobRole = body.get("jobRole");
        if (jobRole == null || jobRole.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Job role is required."));
        }

        try {
            Map<String, Object> result = interviewService.startSession(user, jobRole.trim());
            result.put("success", true);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to start session: " + e.getMessage()));
        }
    }

    /**
     * Submit an answer to a question.
     * POST /api/interview/submit
     * Body: { "sessionId": 1, "questionNumber": 1, "question": "...", "answer": "..." }
     */
    @PostMapping("/submit")
    public ResponseEntity<Map<String, Object>> submitAnswer(
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Please login first."));
        }

        try {
            // --- Safe null-checked parsing ---
            Object rawSessionId = body.get("sessionId");
            Object rawQNum      = body.get("questionNumber");
            Object rawQuestion  = body.get("question");
            Object rawAnswer    = body.get("answer");

            if (rawSessionId == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "sessionId is missing."));
            }
            if (rawQNum == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "questionNumber is missing."));
            }
            if (rawQuestion == null || rawQuestion.toString().isBlank()) {
                return ResponseEntity.badRequest().body(Map.of("error", "question is missing."));
            }

            Long   sessionId      = Long.parseLong(rawSessionId.toString());
            int    questionNumber = Integer.parseInt(rawQNum.toString());
            String question       = rawQuestion.toString();
            String answer         = (rawAnswer != null) ? rawAnswer.toString() : "";

            // Get job role from DB session
            InterviewSession interviewSession = interviewService.getSession(sessionId);
            String jobRole = interviewSession.getJobRole();

            InterviewAnswer saved = interviewService.submitAnswer(
                    sessionId, questionNumber, question, answer, jobRole);

            Map<String, Object> result = new HashMap<>();
            result.put("success",     true);
            result.put("score",       saved.getScore());
            result.put("feedback",    saved.getAiFeedback()  != null ? saved.getAiFeedback()  : "No feedback.");
            result.put("improvement", saved.getImprovement() != null ? saved.getImprovement() : "Keep practising!");
            result.put("answerId",    saved.getId());

            return ResponseEntity.ok(result);

        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid sessionId or questionNumber: " + e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to submit answer: " + e.getMessage()));
        }
    }

    /**
     * Complete the interview session.
     * POST /api/interview/complete
     * Body: { "sessionId": 1 }
     */
    @PostMapping("/complete")
    public ResponseEntity<Map<String, Object>> completeSession(
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Please login first."));
        }

        try {
            Object rawId = body.get("sessionId");
            if (rawId == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "sessionId is missing."));
            }
            Long sessionId = Long.parseLong(rawId.toString());
            InterviewSession completed = interviewService.completeSession(sessionId);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("sessionId", completed.getId());
            result.put("averageScore", completed.getAverageScore());
            result.put("totalQuestions", completed.getTotalQuestions());
            result.put("redirectUrl", "/results/" + completed.getId());

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to complete session: " + e.getMessage()));
        }
    }

    /**
     * Get session details.
     * GET /api/interview/session/{id}
     */
    @GetMapping("/session/{id}")
    public ResponseEntity<Map<String, Object>> getSession(
            @PathVariable Long id,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Please login first."));
        }

        try {
            InterviewSession interviewSession = interviewService.getSession(id);

            Map<String, Object> result = new HashMap<>();
            result.put("id", interviewSession.getId());
            result.put("jobRole", interviewSession.getJobRole());
            result.put("status", interviewSession.getStatus());
            result.put("averageScore", interviewSession.getAverageScore());
            result.put("totalQuestions", interviewSession.getTotalQuestions());

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Health check endpoint (microservice pattern).
     * GET /api/interview/health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> status = new HashMap<>();
        status.put("service", "MockInterview-InterviewService");
        status.put("status", "UP");
        status.put("timestamp", new Date().toString());
        return ResponseEntity.ok(status);
    }
}
