package com.mockinterview.controller;

import com.mockinterview.model.InterviewSession;
import com.mockinterview.model.User;
import com.mockinterview.service.InterviewService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;

/**
 * PageController - Spring MVC Controller for page routing.
 * Handles navigation between HTML pages (Thymeleaf templates).
 */
@Controller
public class PageController {

    @Autowired
    private InterviewService interviewService;

    /**
     * Home page - redirect to login or dashboard based on session.
     */
    @GetMapping("/")
    public String home(HttpSession session) {
        if (session.getAttribute("loggedInUser") != null) {
            return "redirect:/dashboard";
        }
        return "redirect:/login";
    }

    /**
     * Login page.
     */
    @GetMapping("/login")
    public String loginPage(HttpSession session, Model model) {
        if (session.getAttribute("loggedInUser") != null) {
            return "redirect:/dashboard";
        }

        // Pass flash messages from session
        String error = (String) session.getAttribute("errorMessage");
        String success = (String) session.getAttribute("successMessage");

        if (error != null) {
            model.addAttribute("errorMessage", error);
            session.removeAttribute("errorMessage");
        }
        if (success != null) {
            model.addAttribute("successMessage", success);
            session.removeAttribute("successMessage");
        }

        return "login";
    }

    /**
     * Register page.
     */
    @GetMapping("/register")
    public String registerPage(HttpSession session, Model model) {
        if (session.getAttribute("loggedInUser") != null) {
            return "redirect:/dashboard";
        }

        String error = (String) session.getAttribute("errorMessage");
        if (error != null) {
            model.addAttribute("errorMessage", error);
            session.removeAttribute("errorMessage");
        }

        return "register";
    }

    /**
     * Dashboard - main page after login.
     */
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        List<InterviewSession> sessions = interviewService.getUserSessions(user);
        List<String> jobRoles = interviewService.getAvailableJobRoles();

        model.addAttribute("user", user);
        model.addAttribute("sessions", sessions);
        model.addAttribute("jobRoles", jobRoles);
        model.addAttribute("sessionCount", sessions.size());

        // Calculate average score across all sessions
        double overallAvg = sessions.stream()
                .filter(s -> "COMPLETED".equals(s.getStatus()))
                .mapToDouble(InterviewSession::getAverageScore)
                .average().orElse(0.0);
        model.addAttribute("overallAvg", Math.round(overallAvg * 10.0) / 10.0);

        return "dashboard";
    }

    /**
     * Interview page - takes interview.
     */
    @GetMapping("/interview/{sessionId}")
    public String interviewPage(@PathVariable Long sessionId,
                                 HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            InterviewSession interviewSession = interviewService.getSession(sessionId);
            model.addAttribute("interviewSession", interviewSession);
            model.addAttribute("user", user);
            return "interview";
        } catch (Exception e) {
            return "redirect:/dashboard";
        }
    }

    /**
     * Results page - view session results.
     */
    @GetMapping("/results/{sessionId}")
    public String resultsPage(@PathVariable Long sessionId,
                               HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            InterviewSession interviewSession = interviewService.getSession(sessionId);
            var answers = interviewService.getSessionAnswers(sessionId);

            model.addAttribute("session", interviewSession);
            model.addAttribute("answers", answers);
            model.addAttribute("user", user);

            // Grade label
            double avg = interviewSession.getAverageScore();
            String grade;
            if (avg >= 8) grade = "Excellent";
            else if (avg >= 6) grade = "Good";
            else if (avg >= 4) grade = "Average";
            else grade = "Needs Improvement";
            model.addAttribute("grade", grade);

            return "results";
        } catch (Exception e) {
            return "redirect:/dashboard";
        }
    }
}
