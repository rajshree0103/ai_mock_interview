package com.mockinterview.controller;

import com.mockinterview.model.User;
import com.mockinterview.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import java.io.IOException;

/**
 * AuthServlet - Traditional Java Servlet for Login and Registration.
 * Demonstrates Servlet integration with Spring Boot.
 */
@WebServlet(name = "AuthServlet", urlPatterns = {"/auth/login", "/auth/register", "/auth/logout"})
public class AuthServlet extends HttpServlet {

    @Autowired
    private UserService userService;

    @Override
    public void init() throws ServletException {
        super.init();
        // Wire Spring beans into this Servlet
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();

        if ("/auth/login".equals(path)) {
            handleLogin(request, response);
        } else if ("/auth/register".equals(path)) {
            handleRegister(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();

        if ("/auth/logout".equals(path)) {
            handleLogout(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/");
        }
    }

    /**
     * Handle user login.
     */
    private void handleLogin(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Basic validation
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.getSession().setAttribute("errorMessage", "Please enter both email and password.");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            User user = userService.loginUser(email.trim(), password);

            // Store user in session
            HttpSession session = request.getSession(true);
            session.setAttribute("loggedInUser", user);
            session.setAttribute("userId", user.getId());
            session.setAttribute("userName", user.getFullName());
            session.setAttribute("userEmail", user.getEmail());

            System.out.println("[AuthServlet] User logged in: " + user.getEmail());
            response.sendRedirect(request.getContextPath() + "/dashboard");

        } catch (Exception e) {
            request.getSession().setAttribute("errorMessage", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }

    /**
     * Handle new user registration.
     */
    private void handleRegister(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Validation
        if (fullName == null || fullName.trim().isEmpty()) {
            request.getSession().setAttribute("errorMessage", "Full name is required.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }

        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            request.getSession().setAttribute("errorMessage", "Please enter a valid email address.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }

        if (password == null || password.length() < 6) {
            request.getSession().setAttribute("errorMessage", "Password must be at least 6 characters.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }

        if (!password.equals(confirmPassword)) {
            request.getSession().setAttribute("errorMessage", "Passwords do not match.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }

        try {
            User user = userService.registerUser(fullName.trim(), email.trim(), password);

            request.getSession().setAttribute("successMessage",
                "Registration successful! Welcome " + user.getFullName() + ". Please login.");
            response.sendRedirect(request.getContextPath() + "/login");

        } catch (Exception e) {
            request.getSession().setAttribute("errorMessage", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/register");
        }
    }

    /**
     * Handle user logout.
     */
    private void handleLogout(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String email = (String) session.getAttribute("userEmail");
            System.out.println("[AuthServlet] User logged out: " + email);
            session.invalidate();
        }
        response.sendRedirect(request.getContextPath() + "/login");
    }
}
