package com.mockinterview.service;

import com.mockinterview.model.*;
import com.mockinterview.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.*;

/**
 * InterviewService - manages interview sessions, questions, and answers.
 */
@Service
@Transactional
public class InterviewService {

    @Autowired
    private InterviewSessionRepository sessionRepository;

    @Autowired
    private InterviewAnswerRepository answerRepository;

    @Autowired
    private AIService aiService;

    private static final int QUESTIONS_PER_SESSION = 5;

    /**
     * Start a new interview session for a user with the given job role.
     * Generates questions and stores them in session.
     */
    public Map<String, Object> startSession(User user, String jobRole) {
        // Create new session
        InterviewSession session = new InterviewSession(user, jobRole);
        session = sessionRepository.save(session);

        // Generate questions
        List<String> questions = aiService.generateQuestions(jobRole, QUESTIONS_PER_SESSION);
        session.setTotalQuestions(questions.size());
        sessionRepository.save(session);

        Map<String, Object> result = new HashMap<>();
        result.put("sessionId", session.getId());
        result.put("questions", questions);
        result.put("jobRole", jobRole);
        result.put("totalQuestions", questions.size());
        return result;
    }

    /**
     * Submit an answer for a specific question in a session.
     * Evaluates with AI and saves the result.
     */
    public InterviewAnswer submitAnswer(Long sessionId, int questionNumber,
                                        String question, String userAnswer, String jobRole) throws Exception {
        InterviewSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new Exception("Session not found: " + sessionId));

        // Evaluate answer
        Map<String, Object> evaluation = aiService.evaluateAnswer(question, userAnswer, jobRole);

        // Save answer
        InterviewAnswer answer = new InterviewAnswer(session, questionNumber, question);
        answer.setUserAnswer(userAnswer);
        answer.setScore((Double) evaluation.get("score"));
        answer.setAiFeedback((String) evaluation.get("feedback"));
        answer.setImprovement((String) evaluation.get("improvement"));

        return answerRepository.save(answer);
    }

    /**
     * Complete a session - calculate final scores.
     */
    public InterviewSession completeSession(Long sessionId) throws Exception {
        InterviewSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new Exception("Session not found: " + sessionId));

        List<InterviewAnswer> answers = answerRepository.findBySessionOrderByQuestionNumber(session);

        double totalScore = answers.stream().mapToDouble(InterviewAnswer::getScore).sum();
        double avgScore = answers.isEmpty() ? 0 : totalScore / answers.size();

        session.setStatus("COMPLETED");
        session.setTotalScore(totalScore);
        session.setAverageScore(Math.round(avgScore * 10.0) / 10.0);
        session.setCompletedAt(LocalDateTime.now());
        session.setTotalQuestions(answers.size());

        return sessionRepository.save(session);
    }

    /**
     * Get all answers for a session.
     */
    @Transactional(readOnly = true)
    public List<InterviewAnswer> getSessionAnswers(Long sessionId) throws Exception {
        InterviewSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new Exception("Session not found: " + sessionId));
        return answerRepository.findBySessionOrderByQuestionNumber(session);
    }

    /**
     * Get session by ID.
     */
    @Transactional(readOnly = true)
    public InterviewSession getSession(Long sessionId) throws Exception {
        return sessionRepository.findById(sessionId)
                .orElseThrow(() -> new Exception("Session not found: " + sessionId));
    }

    /**
     * Get session history for a user.
     */
    @Transactional(readOnly = true)
    public List<InterviewSession> getUserSessions(User user) {
        return sessionRepository.findByUserOrderByCreatedAtDesc(user);
    }

    /**
     * Get available job roles.
     */
    public List<String> getAvailableJobRoles() {
        return aiService.getAvailableJobRoles();
    }
}
