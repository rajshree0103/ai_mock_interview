package com.mockinterview.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import okhttp3.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * AIService - Generates interview questions and evaluates answers.
 * Uses Google Gemini API if key is set, otherwise uses smart relevance-based local evaluation.
 */
@Service
public class AIService {

    @Value("${ai.api.key:}")
    private String apiKey;

    @Value("${ai.model:gemini-2.0-flash}")
    private String model;

    private final ObjectMapper mapper = new ObjectMapper();

    private static final Map<String, List<String>> QUESTION_BANK = new HashMap<>();
    private static final Map<String, List<String>> TOPIC_KEYWORDS = new HashMap<>();

    static {
        QUESTION_BANK.put("Java Developer", Arrays.asList(
            "What is the difference between JDK, JRE, and JVM?",
            "Explain the concept of Object-Oriented Programming and its four pillars.",
            "What is the difference between ArrayList and LinkedList in Java?",
            "Explain the concept of multithreading in Java and how it differs from multiprocessing.",
            "What are Java generics and why are they useful?"
        ));
        QUESTION_BANK.put("Web Developer", Arrays.asList(
            "Explain the difference between HTML, CSS, and JavaScript.",
            "What is the difference between GET and POST HTTP methods?",
            "What is RESTful API and what are its key principles?",
            "Explain the concept of responsive web design.",
            "What is the difference between synchronous and asynchronous programming in JavaScript?"
        ));
        QUESTION_BANK.put("Data Analyst", Arrays.asList(
            "What is the difference between mean, median, and mode?",
            "Explain the concept of data normalization.",
            "What is a SQL JOIN? Explain different types of JOINs.",
            "What is the difference between structured and unstructured data?",
            "Explain what a data pipeline is and its importance."
        ));
        QUESTION_BANK.put("Python Developer", Arrays.asList(
            "What are Python decorators and how are they used?",
            "Explain the difference between a list, tuple, set, and dictionary in Python.",
            "What is PEP 8 and why is it important?",
            "Explain the concept of generators in Python.",
            "What is the difference between deep copy and shallow copy in Python?"
        ));
        QUESTION_BANK.put("Machine Learning Engineer", Arrays.asList(
            "What is the difference between supervised and unsupervised learning?",
            "Explain overfitting and how to prevent it.",
            "What is the bias-variance tradeoff?",
            "Explain the concept of gradient descent.",
            "What is cross-validation and why is it used?"
        ));
        QUESTION_BANK.put("Database Administrator", Arrays.asList(
            "What is the difference between OLTP and OLAP?",
            "Explain database normalization and its different normal forms.",
            "What are indexes in a database and how do they improve performance?",
            "What is a transaction in a database context? Explain ACID properties.",
            "What is the difference between clustered and non-clustered indexes?"
        ));
        QUESTION_BANK.put("Software Engineer", Arrays.asList(
            "What is the difference between a stack and a queue data structure?",
            "Explain the concept of time complexity and Big O notation.",
            "What are design patterns? Name and explain any two.",
            "Explain the difference between agile and waterfall development methodologies.",
            "What is version control and why is it important in software development?"
        ));
        QUESTION_BANK.put("DevOps Engineer", Arrays.asList(
            "What is CI/CD and why is it important?",
            "Explain the difference between Docker containers and virtual machines.",
            "What is Kubernetes and what problem does it solve?",
            "Explain the concept of Infrastructure as Code (IaC).",
            "What is the difference between blue-green deployment and canary deployment?"
        ));

        // Topic keywords for relevance checking
        TOPIC_KEYWORDS.put("jdk jre jvm", Arrays.asList("jdk","jre","jvm","development kit","runtime environment","virtual machine","bytecode","compiler","platform independent","interpreter"));
        TOPIC_KEYWORDS.put("object oriented oop pillars", Arrays.asList("oop","object","class","inheritance","encapsulation","polymorphism","abstraction","method","instance","overriding","overloading"));
        TOPIC_KEYWORDS.put("arraylist linkedlist", Arrays.asList("arraylist","linkedlist","list","array","linked","index","node","dynamic","collection","random access","sequential"));
        TOPIC_KEYWORDS.put("multithreading multiprocessing thread", Arrays.asList("thread","process","concurrency","parallel","runnable","synchronize","lock","deadlock","cpu","race condition","scheduler"));
        TOPIC_KEYWORDS.put("generics", Arrays.asList("generic","type parameter","template","wildcard","bounded","type erasure","collection","parameterized","compile time"));
        TOPIC_KEYWORDS.put("html css javascript", Arrays.asList("html","css","javascript","markup","stylesheet","script","dom","browser","frontend","structure","style","behavior"));
        TOPIC_KEYWORDS.put("get post http", Arrays.asList("get","post","http","request","response","server","body","url","method","rest","api","header","idempotent"));
        TOPIC_KEYWORDS.put("restful api", Arrays.asList("rest","restful","api","stateless","http","endpoint","resource","json","xml","client","server","uniform","interface"));
        TOPIC_KEYWORDS.put("responsive design", Arrays.asList("responsive","media query","viewport","mobile","css","flexbox","grid","breakpoint","screen","fluid","adaptive"));
        TOPIC_KEYWORDS.put("synchronous asynchronous javascript", Arrays.asList("synchronous","asynchronous","async","await","promise","callback","event loop","blocking","non-blocking"));
        TOPIC_KEYWORDS.put("mean median mode", Arrays.asList("mean","median","mode","average","middle value","frequency","statistics","central tendency","sum","divide"));
        TOPIC_KEYWORDS.put("data normalization", Arrays.asList("normalization","normal form","1nf","2nf","3nf","redundancy","functional dependency","schema","table","relation"));
        TOPIC_KEYWORDS.put("sql join", Arrays.asList("join","inner join","outer join","left join","right join","table","database","query","select","column","foreign key","matching"));
        TOPIC_KEYWORDS.put("structured unstructured data", Arrays.asList("structured","unstructured","relational","database","schema","json","csv","text","image","video","format","semi-structured"));
        TOPIC_KEYWORDS.put("data pipeline", Arrays.asList("pipeline","etl","extract","transform","load","data flow","ingestion","processing","workflow","orchestration","batch","stream"));
        TOPIC_KEYWORDS.put("decorator python", Arrays.asList("decorator","function","wrap","python","higher order","closure","syntax sugar","@","modify","extend","behavior"));
        TOPIC_KEYWORDS.put("list tuple set dictionary python", Arrays.asList("list","tuple","set","dictionary","dict","mutable","immutable","ordered","unordered","key","value","index","hashable","iterable"));
        TOPIC_KEYWORDS.put("generator python", Arrays.asList("generator","yield","iterator","lazy","iterable","next","memory efficient","sequence","gen expression","infinite"));
        TOPIC_KEYWORDS.put("deep copy shallow copy", Arrays.asList("deep copy","shallow copy","reference","value","clone","copy","nested","object","memory","independent","dependent"));
        TOPIC_KEYWORDS.put("supervised unsupervised learning", Arrays.asList("supervised","unsupervised","labeled","unlabeled","train","model","classification","regression","clustering","features","output","prediction"));
        TOPIC_KEYWORDS.put("overfitting", Arrays.asList("overfitting","underfitting","regularization","dropout","validation","test set","generalize","bias","variance","complexity","noise","l1","l2"));
        TOPIC_KEYWORDS.put("bias variance tradeoff", Arrays.asList("bias","variance","tradeoff","error","underfitting","overfitting","model complexity","simple","complex","regularization"));
        TOPIC_KEYWORDS.put("gradient descent", Arrays.asList("gradient","descent","optimization","learning rate","minimum","cost function","loss","backpropagation","update","weights","converge"));
        TOPIC_KEYWORDS.put("cross validation", Arrays.asList("cross validation","k-fold","fold","validation","test","train","split","model selection","generalization","overfitting","evaluation"));
        TOPIC_KEYWORDS.put("oltp olap", Arrays.asList("oltp","olap","transaction","analytical","operational","read","write","data warehouse","query","real-time","batch","reporting"));
        TOPIC_KEYWORDS.put("database normalization normal forms", Arrays.asList("normalization","1nf","2nf","3nf","bcnf","anomaly","redundancy","dependency","primary key","relation","attribute"));
        TOPIC_KEYWORDS.put("index database", Arrays.asList("index","btree","hash","query","search","performance","lookup","primary","secondary","clustered","non-clustered","seek","scan"));
        TOPIC_KEYWORDS.put("acid transaction", Arrays.asList("acid","atomicity","consistency","isolation","durability","transaction","rollback","commit","database","concurrency","lock"));
        TOPIC_KEYWORDS.put("stack queue data structure", Arrays.asList("stack","queue","lifo","fifo","push","pop","enqueue","dequeue","top","front","rear","data structure","overflow","underflow"));
        TOPIC_KEYWORDS.put("time complexity big o", Arrays.asList("time complexity","space complexity","big o","o(n)","o(1)","o(log n)","o(n^2)","logarithmic","linear","quadratic","constant","algorithm","worst case"));
        TOPIC_KEYWORDS.put("design patterns", Arrays.asList("design pattern","singleton","factory","observer","decorator","strategy","adapter","mvc","creational","structural","behavioral","gof"));
        TOPIC_KEYWORDS.put("agile waterfall", Arrays.asList("agile","waterfall","scrum","sprint","iteration","sequential","requirements","methodology","kanban","development cycle","deliverable","milestone"));
        TOPIC_KEYWORDS.put("version control", Arrays.asList("version control","git","svn","repository","commit","branch","merge","conflict","history","track changes","collaboration","github"));
        TOPIC_KEYWORDS.put("cicd", Arrays.asList("ci","cd","continuous integration","continuous deployment","pipeline","build","test","automate","jenkins","github actions","deploy","artifact","release"));
        TOPIC_KEYWORDS.put("docker container virtual machine", Arrays.asList("docker","container","virtual machine","vm","image","dockerfile","hypervisor","os","lightweight","isolation","host","daemon","namespace"));
        TOPIC_KEYWORDS.put("kubernetes", Arrays.asList("kubernetes","k8s","pod","node","cluster","orchestration","deploy","service","ingress","container","scale","helm","master","replica"));
        TOPIC_KEYWORDS.put("infrastructure as code", Arrays.asList("infrastructure","iac","terraform","ansible","cloudformation","code","automate","provision","configuration","idempotent","version control","cloud"));
        TOPIC_KEYWORDS.put("blue green canary deployment", Arrays.asList("blue green","canary","deployment","traffic","rollback","production","staging","gradual","release","zero downtime","switch","version"));
    }

    // =============================================
    // Generate Questions
    // =============================================

    public List<String> generateQuestions(String jobRole, int count) {
        if (isApiKeyValid()) {
            try {
                return generateQuestionsWithAI(jobRole, count);
            } catch (Exception e) {
                System.out.println("[AIService] Gemini API failed, using question bank: " + e.getMessage());
            }
        }
        return getQuestionsFromBank(jobRole, count);
    }

    private List<String> generateQuestionsWithAI(String jobRole, int count) throws Exception {
        String prompt = String.format(
            "Generate exactly %d technical interview questions for a %s position. " +
            "Questions should be medium difficulty, suitable for a student/fresher. " +
            "Return ONLY the questions, one per line, numbered 1. 2. 3. etc. " +
            "Do not include any other text or explanations.", count, jobRole);

        String responseText = callGeminiAPI(prompt);
        List<String> questions = new ArrayList<>();
        for (String line : responseText.split("\n")) {
            line = line.trim().replaceAll("^\\d+[.)\\s]+", "").trim();
            if (!line.isEmpty()) questions.add(line);
        }
        if (questions.size() < count) {
            questions.addAll(getQuestionsFromBank(jobRole, count - questions.size()));
        }
        return questions.subList(0, Math.min(count, questions.size()));
    }

    private List<String> getQuestionsFromBank(String jobRole, int count) {
        List<String> questions = QUESTION_BANK.get(jobRole);
        if (questions == null) {
            for (Map.Entry<String, List<String>> entry : QUESTION_BANK.entrySet()) {
                if (jobRole.toLowerCase().contains(entry.getKey().toLowerCase()) ||
                    entry.getKey().toLowerCase().contains(jobRole.toLowerCase())) {
                    questions = entry.getValue();
                    break;
                }
            }
        }
        if (questions == null) questions = QUESTION_BANK.get("Software Engineer");
        List<String> shuffled = new ArrayList<>(questions);
        Collections.shuffle(shuffled);
        return shuffled.subList(0, Math.min(count, shuffled.size()));
    }

    // =============================================
    // Evaluate Answer
    // =============================================

    public Map<String, Object> evaluateAnswer(String question, String userAnswer, String jobRole) {
        if (isApiKeyValid()) {
            try {
                return evaluateAnswerWithAI(question, userAnswer, jobRole);
            } catch (Exception e) {
                System.out.println("[AIService] Gemini evaluation failed, using local: " + e.getMessage());
            }
        }
        return evaluateAnswerLocally(question, userAnswer);
    }

    private Map<String, Object> evaluateAnswerWithAI(String question, String userAnswer, String jobRole) throws Exception {
        String prompt = String.format(
            "You are a strict technical interviewer evaluating a student's answer for a %s position.\n\n" +
            "Interview Question: %s\n\n" +
            "Student's Answer: %s\n\n" +
            "IMPORTANT EVALUATION RULES:\n" +
            "1. If the answer is completely irrelevant to the question, does not address the question at all, " +
            "contains random/unrelated text, or is intentionally wrong, give a score of 0 or 1.\n" +
            "2. If partially relevant but missing key concepts, give a score between 2 and 5.\n" +
            "3. If relevant and covers the main idea but lacks depth, give a score between 5 and 7.\n" +
            "4. If correct, detailed, and well-explained, give a score between 8 and 10.\n" +
            "5. NEVER reward long answers that don't actually answer the question. Relevance and correctness are everything.\n\n" +
            "Respond ONLY with this exact JSON (no markdown, no extra text):\n" +
            "{\"score\": <integer 0-10>, \"feedback\": \"<what the student got right or wrong>\", \"improvement\": \"<specific tips to improve>\"}",
            jobRole, question, userAnswer);

        String responseText = callGeminiAPI(prompt);
        responseText = responseText.replaceAll("```json", "").replaceAll("```", "").trim();
        int start = responseText.indexOf('{');
        int end = responseText.lastIndexOf('}');
        if (start >= 0 && end > start) {
            responseText = responseText.substring(start, end + 1);
        }

        JsonNode json = mapper.readTree(responseText);
        Map<String, Object> result = new HashMap<>();
        result.put("score", json.get("score").asDouble());
        result.put("feedback", json.get("feedback").asText());
        result.put("improvement", json.get("improvement").asText());
        return result;
    }

    /**
     * Smart local evaluator: checks relevance of the answer to the question.
     * Irrelevant/random answers get 0.
     */
    private Map<String, Object> evaluateAnswerLocally(String question, String userAnswer) {
        Map<String, Object> result = new HashMap<>();

        if (userAnswer == null || userAnswer.trim().isEmpty()) {
            result.put("score", 0.0);
            result.put("feedback", "No answer was provided. You must attempt to answer the question.");
            result.put("improvement", "Even if unsure, try to write something. Partial answers show effort and knowledge.");
            return result;
        }

        String answerLower = userAnswer.trim().toLowerCase();
        String questionLower = question.toLowerCase();
        int wordCount = answerLower.split("\\s+").length;

        List<String> questionKeywords = extractKeywords(questionLower);
        int directMatchCount = 0;
        for (String keyword : questionKeywords) {
            if (answerLower.contains(keyword)) directMatchCount++;
        }

        int topicMatchCount = checkTopicKeywords(questionLower, answerLower);

        boolean isIrrelevant = directMatchCount == 0 && topicMatchCount < 2;
        boolean isWeaklyRelevant = !isIrrelevant && (directMatchCount <= 1 && topicMatchCount < 4);
        boolean isModeratelyRelevant = !isIrrelevant && !isWeaklyRelevant && topicMatchCount < 6;
        boolean isHighlyRelevant = !isIrrelevant && !isWeaklyRelevant && !isModeratelyRelevant;

        double score;
        String feedback;
        String improvement;

        if (isIrrelevant) {
            score = 0.0;
            feedback = "Your answer does not address the question asked. The response appears unrelated to '" + getQuestionTopic(questionLower) + "'.";
            improvement = "Please read the question carefully and answer specifically about: " + getQuestionTopic(questionLower) + ". Do not write off-topic content.";
        } else if (isWeaklyRelevant) {
            if (wordCount < 15) {
                score = 1.5;
                feedback = "Your answer barely touches the topic and is far too brief to be acceptable.";
                improvement = "Explain the concept fully. A good answer requires at least 3-5 sentences covering the definition, how it works, and an example.";
            } else {
                score = 3.0;
                feedback = "Your answer is only slightly related to the question. Most key concepts are missing.";
                improvement = "Focus directly on what was asked. Study the definition and main characteristics of: " + getQuestionTopic(questionLower);
            }
        } else if (isModeratelyRelevant) {
            if (wordCount < 20) {
                score = 4.0;
                feedback = "You're on the right topic but the answer is too short and lacks key details.";
                improvement = "Expand your answer with definitions, how it works, and a practical example. Aim for at least 5 sentences.";
            } else if (wordCount < 60) {
                score = 5.5;
                feedback = "Decent attempt. You've addressed the topic but key concepts and depth are still missing.";
                improvement = "Add technical details, mention related concepts, and explain the 'why' behind your answer.";
            } else {
                score = 6.5;
                feedback = "Good answer that covers the main topic. A bit more depth would make it stronger.";
                improvement = "Review the complete definition and add any missing technical nuances or edge cases.";
            }
        } else {
            if (wordCount < 20) {
                score = 5.0;
                feedback = "You've identified the key concepts, but the answer is too brief for an interview setting.";
                improvement = "Elaborate fully. Interviewers want to hear your complete understanding, not just keywords.";
            } else if (wordCount < 60) {
                score = 6.5;
                feedback = "Good answer covering the main points. A bit more explanation would make it excellent.";
                improvement = "Add a real-world example or explain how this concept is used in practice.";
            } else if (wordCount < 120) {
                score = 7.5;
                feedback = "Well-explained answer with solid understanding demonstrated.";
                improvement = "To score higher, include practical examples, edge cases, or how this applies in real projects.";
            } else {
                score = 8.5;
                feedback = "Excellent, detailed answer! You demonstrated strong understanding of the concept.";
                improvement = "Great response! You could also mention common pitfalls or advanced use cases for a perfect answer.";
            }
        }

        result.put("score", score);
        result.put("feedback", feedback);
        result.put("improvement", improvement);
        return result;
    }

    private List<String> extractKeywords(String question) {
        Set<String> stopWords = new HashSet<>(Arrays.asList(
            "what","is","are","how","why","when","where","which","explain","describe",
            "define","difference","between","and","or","a","an","in","of","to","for",
            "with","its","it","this","that","these","those","can","do","does","have",
            "has","concept","types","type","give","example","use","used","any","two","some"
        ));
        List<String> keywords = new ArrayList<>();
        for (String word : question.replaceAll("[^a-z0-9\\s/]", " ").split("\\s+")) {
            if (word.length() > 2 && !stopWords.contains(word)) keywords.add(word);
        }
        return keywords;
    }

    private int checkTopicKeywords(String question, String answer) {
        int bestMatch = 0;
        for (Map.Entry<String, List<String>> entry : TOPIC_KEYWORDS.entrySet()) {
            boolean topicRelevant = false;
            for (String topicWord : entry.getKey().split("\\s+")) {
                if (question.contains(topicWord)) { topicRelevant = true; break; }
            }
            if (topicRelevant) {
                int count = 0;
                for (String kw : entry.getValue()) { if (answer.contains(kw)) count++; }
                if (count > bestMatch) bestMatch = count;
            }
        }
        return bestMatch;
    }

    private String getQuestionTopic(String question) {
        if (question.contains("jdk") || question.contains("jvm")) return "JDK, JRE, and JVM";
        if (question.contains("object-oriented") || question.contains("oop")) return "OOP and its four pillars";
        if (question.contains("arraylist") || question.contains("linkedlist")) return "ArrayList vs LinkedList";
        if (question.contains("thread") || question.contains("multithreading")) return "Multithreading in Java";
        if (question.contains("generics")) return "Java Generics";
        if (question.contains("html") || question.contains("css")) return "HTML, CSS, and JavaScript";
        if (question.contains("get") && question.contains("post")) return "HTTP GET vs POST methods";
        if (question.contains("rest")) return "RESTful API";
        if (question.contains("responsive")) return "Responsive Web Design";
        if (question.contains("synchronous") || question.contains("asynchronous")) return "Synchronous vs Asynchronous JavaScript";
        if (question.contains("mean") || question.contains("median")) return "Mean, Median, and Mode";
        if (question.contains("normalization") && question.contains("data")) return "Data Normalization";
        if (question.contains("join") || question.contains("sql")) return "SQL JOINs";
        if (question.contains("structured")) return "Structured vs Unstructured Data";
        if (question.contains("pipeline")) return "Data Pipeline";
        if (question.contains("decorator")) return "Python Decorators";
        if (question.contains("generator")) return "Python Generators";
        if (question.contains("deep copy")) return "Deep Copy vs Shallow Copy";
        if (question.contains("supervised")) return "Supervised vs Unsupervised Learning";
        if (question.contains("overfit")) return "Overfitting and Prevention";
        if (question.contains("bias") && question.contains("variance")) return "Bias-Variance Tradeoff";
        if (question.contains("gradient")) return "Gradient Descent";
        if (question.contains("cross-validation")) return "Cross-Validation";
        if (question.contains("oltp") || question.contains("olap")) return "OLTP vs OLAP";
        if (question.contains("normalization")) return "Database Normalization";
        if (question.contains("index")) return "Database Indexes";
        if (question.contains("acid") || question.contains("transaction")) return "Database Transactions and ACID";
        if (question.contains("stack") || question.contains("queue")) return "Stack and Queue Data Structures";
        if (question.contains("big o") || question.contains("complexity")) return "Time Complexity and Big O Notation";
        if (question.contains("design pattern")) return "Design Patterns";
        if (question.contains("agile") || question.contains("waterfall")) return "Agile vs Waterfall";
        if (question.contains("version control")) return "Version Control";
        if (question.contains("ci/cd") || question.contains("continuous")) return "CI/CD Pipeline";
        if (question.contains("docker") || question.contains("container")) return "Docker vs Virtual Machines";
        if (question.contains("kubernetes")) return "Kubernetes";
        if (question.contains("infrastructure as code")) return "Infrastructure as Code";
        if (question.contains("blue-green") || question.contains("canary")) return "Blue-Green vs Canary Deployment";
        return "the technical concept asked in the question";
    }

    // =============================================
    // Google Gemini API Call
    // =============================================

    /**
     * Calls the Google Gemini REST API (generateContent endpoint).
     * Docs: https://ai.google.dev/api/generate-content
     */
    private String callGeminiAPI(String userPrompt) throws Exception {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();

        // Gemini request body format
        Map<String, Object> part = new LinkedHashMap<>();
        part.put("text", userPrompt);

        Map<String, Object> content = new LinkedHashMap<>();
        content.put("parts", Collections.singletonList(part));

        Map<String, Object> requestMap = new LinkedHashMap<>();
        requestMap.put("contents", Collections.singletonList(content));

        String requestBody = mapper.writeValueAsString(requestMap);

        // Gemini endpoint: https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}
        String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                + model + ":generateContent?key=" + apiKey;

        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(requestBody, MediaType.get("application/json")))
                .addHeader("Content-Type", "application/json")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                String errBody = response.body() != null ? response.body().string() : "";
                throw new Exception("Gemini API call failed with status " + response.code() + ": " + errBody);
            }
            String responseBody = response.body().string();
            // Gemini response: candidates[0].content.parts[0].text
            JsonNode jsonNode = mapper.readTree(responseBody);
            return jsonNode
                    .get("candidates").get(0)
                    .get("content")
                    .get("parts").get(0)
                    .get("text").asText();
        }
    }

    private boolean isApiKeyValid() {
        return apiKey != null && !apiKey.isBlank() && !apiKey.equals("YOUR_GEMINI_API_KEY_HERE");
    }

    public List<String> getAvailableJobRoles() {
        return Arrays.asList(
            "Java Developer", "Web Developer", "Python Developer", "Data Analyst",
            "Machine Learning Engineer", "Database Administrator", "Software Engineer", "DevOps Engineer"
        );
    }
}
