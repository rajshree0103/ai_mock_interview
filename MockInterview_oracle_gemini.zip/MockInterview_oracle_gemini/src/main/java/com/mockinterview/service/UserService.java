package com.mockinterview.service;

import com.mockinterview.model.User;
import com.mockinterview.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

/**
 * UserService - handles user registration, login, and profile management.
 */
@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    /**
     * Register a new user.
     * Checks for duplicate email and encodes password before saving.
     */
    public User registerUser(String fullName, String email, String rawPassword) throws Exception {
        // Check if email already exists
        if (userRepository.existsByEmail(email)) {
            throw new Exception("Email already registered. Please login.");
        }

        // Encode password using BCrypt
        String encodedPassword = passwordEncoder.encode(rawPassword);

        User user = new User(fullName, email, encodedPassword);
        return userRepository.save(user);
    }

    /**
     * Login: verify email and password.
     * Returns User object if credentials match, null otherwise.
     */
    @Transactional(readOnly = true)
    public User loginUser(String email, String rawPassword) throws Exception {
        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isEmpty()) {
            throw new Exception("No account found with this email. Please register first.");
        }

        User user = userOpt.get();

        if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
            throw new Exception("Incorrect password. Please try again.");
        }

        return user;
    }

    /**
     * Find user by ID.
     */
    @Transactional(readOnly = true)
    public User getUserById(Long id) throws Exception {
        return userRepository.findById(id)
                .orElseThrow(() -> new Exception("User not found with id: " + id));
    }

    /**
     * Find user by email.
     */
    @Transactional(readOnly = true)
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    /**
     * Check if email exists.
     */
    @Transactional(readOnly = true)
    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }
}
