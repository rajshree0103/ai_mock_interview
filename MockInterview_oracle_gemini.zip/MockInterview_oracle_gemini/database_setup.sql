-- ================================================
-- MockInterview Database Setup Script (Oracle)
-- Run these statements in SQL*Plus or SQL Developer
-- BEFORE starting the application
-- ================================================

-- 1. Connect as SYSDBA and create the schema user
--    (run as: sqlplus sys/yourpassword@XE as sysdba)
CREATE USER mockinterview IDENTIFIED BY mockinterview;
GRANT CONNECT, RESOURCE TO mockinterview;
GRANT UNLIMITED TABLESPACE TO mockinterview;

-- 2. Connect as the new user
--    (run as: sqlplus mockinterview/mockinterview@XE)

-- ================================================
-- NOTE: Tables below are created automatically by
-- Hibernate (ddl-auto=update). You only need to
-- run this manually if you want to pre-create them.
-- ================================================

-- Sequences (Oracle uses sequences instead of SERIAL/BIGSERIAL)
CREATE SEQUENCE users_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE interview_sessions_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE interview_answers_seq START WITH 1 INCREMENT BY 1;

-- Users table
CREATE TABLE users (
    id          NUMBER(19)    DEFAULT users_seq.NEXTVAL PRIMARY KEY,
    full_name   VARCHAR2(100) NOT NULL,
    email       VARCHAR2(150) NOT NULL UNIQUE,
    password    VARCHAR2(255) NOT NULL,
    role        VARCHAR2(50)  DEFAULT 'STUDENT',
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- Interview Sessions table
CREATE TABLE interview_sessions (
    id              NUMBER(19)    DEFAULT interview_sessions_seq.NEXTVAL PRIMARY KEY,
    user_id         NUMBER(19)    NOT NULL REFERENCES users(id),
    job_role        VARCHAR2(150) NOT NULL,
    total_questions NUMBER(10)    DEFAULT 0,
    total_score     BINARY_DOUBLE DEFAULT 0,
    average_score   BINARY_DOUBLE DEFAULT 0,
    status          VARCHAR2(50)  DEFAULT 'IN_PROGRESS',
    created_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    completed_at    TIMESTAMP
);

-- Interview Answers table
CREATE TABLE interview_answers (
    id              NUMBER(19)    DEFAULT interview_answers_seq.NEXTVAL PRIMARY KEY,
    session_id      NUMBER(19)    NOT NULL REFERENCES interview_sessions(id),
    question_number NUMBER(10)    NOT NULL,
    question        CLOB          NOT NULL,
    user_answer     CLOB,
    score           BINARY_DOUBLE DEFAULT 0,
    ai_feedback     CLOB,
    improvement     CLOB,
    answered_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for better query performance
CREATE INDEX idx_users_email       ON users(email);
CREATE INDEX idx_sessions_user_id  ON interview_sessions(user_id);
CREATE INDEX idx_answers_session_id ON interview_answers(session_id);

-- Verify tables
SELECT table_name FROM user_tables ORDER BY table_name;
